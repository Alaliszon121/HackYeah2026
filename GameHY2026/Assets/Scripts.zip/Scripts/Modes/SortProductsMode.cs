using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using Random = UnityEngine.Random;

namespace PinkTaxGame
{
    public class SortProductsMode : GameMode
    {
        [Header("Input Actions")]
        [Tooltip("Assign 'Gameplay/Point' from PinkTaxGame Input Actions.")]
        [SerializeField] private InputActionReference pointAction;

        [Tooltip("Assign 'Gameplay/DragPress' from PinkTaxGame Input Actions.")]
        [SerializeField] private InputActionReference dragPressAction;

        [Header("Camera & Mechanics")]
        [SerializeField] private Camera puzzleCamera;
        [SerializeField] private float maxDropDistance = 1.5f;

        [Header("Layout")]
        [SerializeField] private SlotGenerator slotGenerator;

        private readonly List<Transform> slots = new List<Transform>();
        private readonly List<GameObject> productObjects = new List<GameObject>();
        private readonly List<ProductInteractable> productInteractables = new List<ProductInteractable>();
        private readonly Dictionary<Transform, ProductInteractable> slotOccupants = new Dictionary<Transform, ProductInteractable>();
        private readonly List<ProductData> playerOrder = new List<ProductData>();
        private readonly List<ProductData> correctOrder = new List<ProductData>();

        private ProductInteractable draggedItem;
        private Transform currentShelf;
        private float currentShelfWidth;
        private Vector3 currentRowLocalOffset;
        private bool inputEnabled;

        public IReadOnlyList<ProductData> PlayerOrder => playerOrder;
        public IReadOnlyList<ProductData> CorrectOrder => correctOrder;

        private void Awake()
        {
            if (puzzleCamera == null)
                puzzleCamera = Camera.main;

            if (slotGenerator == null)
                slotGenerator = FindAnyObjectByType<SlotGenerator>();
        }

        private void OnDisable()
        {
            DisableInput();
        }

        private void Update()
        {
            if (inputEnabled)
                HandleDrag();
        }

        public override void Setup(SublevelData sublevel)
        {
            Stop();
            ResetState();
            base.Setup(sublevel);

            if (sublevel == null)
            {
                Debug.LogError("SortProductsMode: SublevelData is null.");
                return;
            }

            if (sublevel.ModeType != ModeType.SortProducts)
            {
                Debug.LogError("SortProductsMode: Received a sublevel for the wrong mode.");
                return;
            }

            if (sublevel.Products.Count < 2)
            {
                Debug.LogError("SortProductsMode: SortProducts requires at least two products.");
                return;
            }

            foreach (ProductData product in sublevel.Products)
            {
                if (product == null)
                {
                    Debug.LogError("SortProductsMode: Sublevel contains a null product.");
                    return;
                }

                correctOrder.Add(product);
            }

            correctOrder.Sort((first, second) => first.PriceGrosze.CompareTo(second.PriceGrosze));

            if (slotGenerator == null)
                slotGenerator = FindAnyObjectByType<SlotGenerator>();

            if (slotGenerator == null)
                Debug.LogError("SortProductsMode: No SlotGenerator exists in the scene.");
        }

        public void SetShelfContext(
            Transform shelfTransform,
            float shelfWidth,
            Vector3 rowLocalOffset
        )
        {
            currentShelf = shelfTransform;
            currentShelfWidth = shelfWidth;
            currentRowLocalOffset = rowLocalOffset;
        }

        public void SetProductObjects(IReadOnlyList<GameObject> objects)
        {
            productObjects.Clear();

            if (objects == null)
                return;

            foreach (GameObject productObject in objects)
                productObjects.Add(productObject);
        }

        public override void Play()
        {
            if (currentSublevel == null || currentSublevel.ModeType != ModeType.SortProducts)
            {
                Debug.LogError("SortProductsMode: Cannot play without a valid SortProducts sublevel.");
                return;
            }

            if (slotGenerator == null)
            {
                Debug.LogError("SortProductsMode: SlotGenerator is not assigned.");
                return;
            }

            if (currentShelf == null)
            {
                Debug.LogError("SortProductsMode: Current shelf is not assigned.");
                return;
            }

            if (currentShelfWidth <= 0f)
            {
                Debug.LogError("SortProductsMode: Current shelf width must be greater than zero.");
                return;
            }

            slots.Clear();
            slots.AddRange(
                slotGenerator.GenerateSlots(
                    currentSublevel.Products.Count,
                    currentShelf,
                    currentShelfWidth,
                    currentRowLocalOffset
                )
            );

            if (slots.Count < currentSublevel.Products.Count)
            {
                Debug.LogError("SortProductsMode: SlotGenerator did not create enough slots.");
                return;
            }

            if (productObjects.Count != currentSublevel.Products.Count)
            {
                Debug.LogError(
                    $"SortProductsMode: Expected {currentSublevel.Products.Count} spawned product objects, " +
                    $"but received {productObjects.Count}."
                );
                return;
            }

            InitializeBoard();
            EnableInput();
        }

        public override void Submit()
        {
            if (currentSublevel == null || currentSublevel.ModeType != ModeType.SortProducts)
            {
                Debug.LogError("SortProductsMode: Cannot submit without a valid SortProducts sublevel.");
                return;
            }

            if (gameManager == null)
            {
                Debug.LogError("SortProductsMode: GameManager is not initialized.");
                return;
            }

            UpdatePlayerOrder();

            if (playerOrder.Count != currentSublevel.Products.Count)
            {
                Debug.LogWarning("SortProductsMode: Not every product currently occupies a sorting slot.");
                return;
            }

            int points = CalculatePoints();

            ModeResult result = ModeResult.CreateSortResult(
                currentSublevel.Products,
                playerOrder,
                correctOrder,
                points,
                MaxPoints
            );

            gameManager.CompleteCurrentSublevel(result);
        }

        public override void Stop()
        {
            DisableInput();
            draggedItem = null;
        }

        public bool VerifySortingOrder()
        {
            UpdatePlayerOrder();

            if (playerOrder.Count != currentSublevel?.Products.Count)
                return false;

            for (int i = 1; i < playerOrder.Count; i++)
            {
                if (playerOrder[i - 1].PriceGrosze > playerOrder[i].PriceGrosze)
                    return false;
            }

            return true;
        }

        private int CalculatePoints()
        {
            int productCount = playerOrder.Count;
            int totalPairs = productCount * (productCount - 1) / 2;

            if (totalPairs <= 0)
                return MaxPoints;

            int correctlyOrderedPairs = 0;

            for (int i = 0; i < productCount - 1; i++)
            {
                for (int j = i + 1; j < productCount; j++)
                {
                    if (playerOrder[i].PriceGrosze <= playerOrder[j].PriceGrosze)
                        correctlyOrderedPairs++;
                }
            }

            float correctFraction = (float)correctlyOrderedPairs / totalPairs;
            return Mathf.RoundToInt(correctFraction * MaxPoints);
        }

        private void InitializeBoard()
        {
            slotOccupants.Clear();
            productInteractables.Clear();
            playerOrder.Clear();
            draggedItem = null;

            List<Transform> randomizedSlots = new List<Transform>(slots);
            ShuffleList(randomizedSlots);

            for (int i = 0; i < currentSublevel.Products.Count; i++)
            {
                ProductData product = currentSublevel.Products[i];
                GameObject productObject = productObjects[i];
                Transform targetSlot = randomizedSlots[i];

                if (productObject == null)
                {
                    Debug.LogError($"SortProductsMode: Spawned product object {i} is null.");
                    return;
                }

                ProductInteractable interactable = productObject.GetComponent<ProductInteractable>();

                if (interactable == null)
                    interactable = productObject.AddComponent<ProductInteractable>();

                interactable.Setup(product);
                interactable.CurrentSlot = targetSlot;

                productObject.transform.SetPositionAndRotation(targetSlot.position, targetSlot.rotation);

                slotOccupants[targetSlot] = interactable;
                productInteractables.Add(interactable);
            }

            UpdatePlayerOrder();
        }

        private void EnableInput()
        {
            if (inputEnabled)
                return;

            if (dragPressAction != null)
            {
                dragPressAction.action.performed += OnDragPressPerformed;
                dragPressAction.action.canceled += OnDragPressCanceled;
                dragPressAction.action.Enable();
            }

            if (pointAction != null)
                pointAction.action.Enable();

            inputEnabled = true;
        }

        private void DisableInput()
        {
            if (!inputEnabled)
                return;

            if (dragPressAction != null)
            {
                dragPressAction.action.performed -= OnDragPressPerformed;
                dragPressAction.action.canceled -= OnDragPressCanceled;
                dragPressAction.action.Disable();
            }

            if (pointAction != null)
                pointAction.action.Disable();

            inputEnabled = false;
        }

        private void OnDragPressPerformed(InputAction.CallbackContext context)
        {
            if (puzzleCamera == null || pointAction == null)
                return;

            Vector2 pointerPosition = pointAction.action.ReadValue<Vector2>();
            Ray ray = puzzleCamera.ScreenPointToRay(pointerPosition);

            if (!Physics.Raycast(ray, out RaycastHit hit))
                return;

            ProductInteractable item = hit.collider.GetComponentInParent<ProductInteractable>();

            if (item != null && productInteractables.Contains(item))
                StartDragging(item);
        }

        private void OnDragPressCanceled(InputAction.CallbackContext context)
        {
            if (draggedItem != null)
                EndDragging();
        }

        private void StartDragging(ProductInteractable item)
        {
            draggedItem = item;
            draggedItem.OriginalSlot = item.CurrentSlot;
            draggedItem.OriginalPosition = item.transform.position;

            if (draggedItem.OriginalSlot == null)
                return;

            if (slotOccupants.TryGetValue(draggedItem.OriginalSlot, out ProductInteractable occupant) && occupant == draggedItem)
                slotOccupants.Remove(draggedItem.OriginalSlot);
        }

        private void HandleDrag()
        {
            if (draggedItem == null || pointAction == null || puzzleCamera == null)
                return;

            Vector2 pointerPosition = pointAction.action.ReadValue<Vector2>();
            Ray ray = puzzleCamera.ScreenPointToRay(pointerPosition);
            Plane dragPlane = new Plane(-puzzleCamera.transform.forward, draggedItem.OriginalPosition);

            if (!dragPlane.Raycast(ray, out float enter))
                return;

            draggedItem.transform.position = ray.GetPoint(enter);
        }

        private void EndDragging()
        {
            Transform targetSlot = GetClosestSlot(draggedItem.transform.position);

            if (targetSlot != null && Vector3.Distance(draggedItem.transform.position, targetSlot.position) <= maxDropDistance)
            {
                if (slotOccupants.TryGetValue(targetSlot, out ProductInteractable occupant) && occupant != null)
                {
                    occupant.CurrentSlot = draggedItem.OriginalSlot;
                    occupant.transform.position = draggedItem.OriginalSlot.position;

                    if (draggedItem.OriginalSlot != null)
                        slotOccupants[draggedItem.OriginalSlot] = occupant;
                }

                draggedItem.CurrentSlot = targetSlot;
                draggedItem.transform.position = targetSlot.position;
                slotOccupants[targetSlot] = draggedItem;
            }
            else
            {
                draggedItem.CurrentSlot = draggedItem.OriginalSlot;
                draggedItem.transform.position = draggedItem.OriginalPosition;

                if (draggedItem.OriginalSlot != null)
                    slotOccupants[draggedItem.OriginalSlot] = draggedItem;
            }

            draggedItem = null;
            UpdatePlayerOrder();
        }

        private void UpdatePlayerOrder()
        {
            playerOrder.Clear();

            foreach (Transform slot in slots)
            {
                if (slotOccupants.TryGetValue(slot, out ProductInteractable item) && item != null && item.ProductData != null)
                    playerOrder.Add(item.ProductData);
            }
        }

        private Transform GetClosestSlot(Vector3 position)
        {
            Transform closest = null;
            float minimumDistance = float.MaxValue;

            foreach (Transform slot in slots)
            {
                float distance = Vector3.Distance(position, slot.position);

                if (distance < minimumDistance)
                {
                    minimumDistance = distance;
                    closest = slot;
                }
            }

            return closest;
        }

        private void ResetState()
        {
            slots.Clear();
            productObjects.Clear();
            productInteractables.Clear();
            slotOccupants.Clear();
            playerOrder.Clear();
            correctOrder.Clear();
            draggedItem = null;
            currentShelf = null;
            currentShelfWidth = 0f;
            currentRowLocalOffset = Vector3.zero;
        }

        private void ShuffleList<T>(List<T> list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                int randomIndex = Random.Range(i, list.Count);
                (list[i], list[randomIndex]) = (list[randomIndex], list[i]);
            }
        }
    }
}
